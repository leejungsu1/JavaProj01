package ver05;

public interface MenuItem {
	
	int 데이터입력=1, 데이터검색=2, 데이터삭제=3, 프로그램종료=4;

}
