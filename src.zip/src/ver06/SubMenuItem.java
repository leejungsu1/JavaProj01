package ver06;

public interface SubMenuItem {
	
	int 일반=1, 학교동창=2, 회사동료=3;

}
