package ver08;

public class MenuSelectException extends Exception {
	
	public MenuSelectException() {
		super("1~5 중의 하나의 숫자를 입력하세요.");
	}
}
